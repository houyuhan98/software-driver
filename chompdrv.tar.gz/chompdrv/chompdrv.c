#include <libusb-1.0/libusb.h>
#include <stdio.h>
#include <stdlib.h>
#include <linux/uinput.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

static void emit(int fd, int type, int code, int val)
{
	struct input_event ie;

	ie.type = type;
	ie.code = code;
	ie.value = val;
	/* timestamp values below are ignored */
	ie.time.tv_sec = 0;
	ie.time.tv_usec = 0;

	write(fd, &ie, sizeof(ie));
}

void printdev(libusb_device *dev); //prototype of the function

int main() {
	libusb_device **devs; //pointer to pointer of device, used to retrieve a list of devices
	libusb_context *ctx = NULL; //a libusb session
	libusb_device_handle *dev_handle; //a device handle
	int r; //for return values
	ssize_t cnt; //holding number of devices in list
	r = libusb_init(&ctx); //initialize a library session
	if(r < 0) {
		printf("Init Error\n");
		return 1;
	}
	libusb_set_debug(ctx, 3); //set verbosity level to 3, as suggested in the documentation
	cnt = libusb_get_device_list(ctx, &devs); //get the list of devices
	if(cnt < 0) {
		printf("Get Device Error\n");
	}
	printf("%ld Devices in list.\n", cnt); //print total number of usb devices
	ssize_t i; //for iterating through the list
	for(i = 0; i < cnt; i++) {
		printdev(devs[i]); //print specs of this device
	}
	libusb_free_device_list(devs, 1); //free the list, unref the devices in it

	dev_handle = libusb_open_device_with_vid_pid(ctx, 0x9a7a, 0xba17); //these are vendorID and productID I found for my usb device
	if(dev_handle == NULL)
		printf("Cannot open device\n");
	else
		printf("Device Opened\n");
	

	int actual; //used to find out how many bytes were written
	if(libusb_kernel_driver_active(dev_handle, 0) == 1) { //find out if kernel driver is attached
		printf("Kernel Driver Active\n");
		if(libusb_detach_kernel_driver(dev_handle, 0) == 0) //detach it
			printf("Kernel Driver Detached!\n");
	}
	r = libusb_claim_interface(dev_handle, 0); //claim interface 0 (the first) of device (mine had jsut 1)
	if(r < 0) {
		printf("Cannot Claim Interface\n");
		return 1;
	}
	printf("Claimed Interface\n");
	printf("Reading...\n");
	char device_input;

	struct uinput_user_dev uud;
	int version, rc, fd;

	fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
//	rc = ioctl(fd, UI_GET_VERSION, &version);

	/*
	 * The ioctls below will enable the device that is about to be
	 * created, to pass key events, in this case the Button 0, X and Y axises.
	 */
	ioctl(fd, UI_SET_EVBIT, EV_KEY);
	ioctl(fd, UI_SET_EVBIT, EV_ABS);
	ioctl(fd, UI_SET_KEYBIT, BTN_0);
	ioctl(fd, UI_SET_ABSBIT, ABS_X);
	ioctl(fd, UI_SET_ABSBIT, ABS_Y);

	memset(&uud, 0, sizeof(uud));
	uud.id.bustype = BUS_USB;
	uud.id.vendor = 0x9A7A;
	uud.id.product = 0xBA17;
	snprintf(uud.name, UINPUT_MAX_NAME_SIZE, "js device");

	uud.absmax[ABS_X] = 32767; 
	uud.absmin[ABS_X] = -32767;
	uud.absmax[ABS_Y] = 32767; 
	uud.absmin[ABS_Y] = -32767;
	write(fd, &uud, sizeof(uud));

	ioctl(fd, UI_DEV_CREATE);

	/*
	 * On UI_DEV_CREATE the kernel will create the device node for this
	 * device. We are inserting a pause here so that userspace has time
	 * to detect, initialize the new device, and can start listening to
	 * the event, otherwise it will not notice the event we are about
	 * to send. This pause is only needed in our example code!
	 */

	/* Key press, report the event, send key release, and report again */

	/*
	 * Give userspace some time to read the events before we destroy the
	 * device with UI_DEV_DESTOY.
	 */
	sleep(1);
	char old_value = 0;

	while(1){
		r = libusb_interrupt_transfer(dev_handle, (129 | LIBUSB_ENDPOINT_IN), &device_input, 1, &actual, 0);
		if(device_input != old_value){
			int button_value = ((device_input) & 0x10) >> 4;
			int x_value = ((device_input) & 0xC) >> 2;
			int y_value = ((device_input) & 0x3);

			emit(fd, EV_KEY, BTN_0, button_value);
			if(x_value == 1){
				emit(fd, EV_ABS, ABS_X, -32767);
			}else if(x_value == 2){
				emit(fd, EV_ABS, ABS_X, 0);
			}else if(x_value == 3){
				emit(fd, EV_ABS, ABS_X, 32767);
			}
			if(y_value == 1){
				emit(fd, EV_ABS, ABS_Y, 32767);
			}else if(y_value == 2){
				emit(fd, EV_ABS, ABS_Y, 0);
			}else if(y_value == 3){
				emit(fd, EV_ABS, ABS_Y, -32767);
			}
			emit(fd, EV_SYN, SYN_REPORT, 0);
			old_value = device_input;
		}
	}

	ioctl(fd, UI_DEV_DESTROY);
	close(fd);
	libusb_exit(ctx); //close the session
	return 0;
}

void printdev(libusb_device *dev) {
	struct libusb_device_descriptor desc;
	int r = libusb_get_device_descriptor(dev, &desc);
	if (r < 0) {
		printf("failed to get device descriptor\n");
		return;
	}
	printf("Number of possible configurations: %d ", (int)desc.bNumConfigurations);
	printf("Device Class: %d ", (int)desc.bDeviceClass);
	printf("VendorID : %x ProductID: %x \n", desc.idVendor, desc.idProduct);
	struct libusb_config_descriptor *config;
	libusb_get_config_descriptor(dev, 0, &config);
	printf("Interfaces: %d ||| ", (int)config->bNumInterfaces);
	const struct libusb_interface *inter;
	const struct libusb_interface_descriptor *interdesc;
	const struct libusb_endpoint_descriptor *epdesc;
	for(int i=0; i<(int)config->bNumInterfaces; i++) {
		inter = &config->interface[i];
		printf("Number of alternate settings: %d | ",inter->num_altsetting);
		for(int j=0; j<inter->num_altsetting; j++) {
			interdesc = &inter->altsetting[j];
			printf("Interface Number: %d | ", (int)interdesc->bInterfaceNumber);
			printf("Number of endpoints: %d | ", (int)interdesc->bNumEndpoints);
			for(int k=0; k<(int)interdesc->bNumEndpoints; k++) {
				epdesc = &interdesc->endpoint[k];
				printf("Descriptor Type: %d | ", (int)epdesc->bDescriptorType);
				printf("EP Address: %d | ", (int)epdesc->bEndpointAddress);
			
			}
		}
		printf("\n\n\n");
		libusb_free_config_descriptor(config);
	}
}
